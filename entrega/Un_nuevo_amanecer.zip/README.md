# Un nuevo amanecer

*Un nuevo amanecer* es un videojuego académico de plataformas 2D con desplazamiento lateral y terror psicológico. Tras recibir una llamada inquietante de su hermano menor, Michael, Harry regresa al orfanato para buscarlo. La niebla cubre el edificio y las pinturas de Michael revelan, poco a poco, lo ocurrido allí.

## Equipo

**Número del grupo** · 1

| Integrante |
| --- |
| Anthony Alangasí|
| Anahí Achote    |
| Gary Defas      |
| Lindsay Guzmán  |

## Cómo ejecutar el proyecto

Usa un navegador moderno y **Node.js 24 con npm**, la versión con la que se probó el proyecto. Abre una terminal en la carpeta del proyecto y ejecuta lo siguiente.

```bash
npm ci
npm run dev
```

Abre [http://localhost:5173](http://localhost:5173) o la dirección que indique Vite en la terminal. Elige **Iniciar** para ver la llamada de Michael o **Continuar** para cargar el último punto de control. `Enter` continúa si hay una partida guardada y abre la introducción en la primera visita. Mantén la terminal abierta mientras juegas y presiona `Ctrl+C` para detener el servidor. En los siguientes arranques basta con `npm run dev` si las dependencias siguen instaladas.

Para generar y revisar la compilación de producción, ejecuta estos comandos.

```bash
npm run build
npm run preview
```

La compilación se genera en `dist/`. Abre [http://localhost:4173](http://localhost:4173) o la dirección que muestre la terminal.


## Controles

Usa la linterna para iluminar a La Sombra. El haz detiene su avance y, tras acumular suficiente exposición, la criatura desaparece. Puedes recuperar energía sobre una franja **Recarga** con la linterna apagada.

El contacto con La Sombra quita un punto de salud. Si Harry pierde los tres puntos, elige **Reintentar desde punto de control** o pulsa `R` para volver al último punto alcanzado.

| Acción | Escritorio | Móvil |
| --- | --- | --- |
| Moverse | `A` y `D` o flechas izquierda y derecha | Botones de dirección |
| Saltar | `W` o `↑` | Botón de salto |
| Activar o apagar la linterna | `J` o clic izquierdo | Botón de linterna |
| Pausar | `Esc` | Botón **Pausa** |

## Guardado y puntaje

La primera franja de recarga del pasillo funciona como punto de control. Al pasar por encima, el juego guarda el progreso en este navegador con `localStorage`. **Continuar** y **Reintentar desde punto de control** devuelven a Harry a ese punto con la salud y la linterna llenas. **Iniciar** vuelve a la entrada.

Cada pintura distinta que iluminas vale un punto por partida. El HUD muestra el puntaje actual y el récord guardado en el navegador. **Iniciar** abre una partida con cero puntos y conserva el récord y la galería.

El menú de pausa permite continuar, reiniciar desde el punto de control, cambiar la preferencia de audio o volver al menú principal. Esta preferencia también controla el ambiente y los efectos de la cámara final. En dispositivos táctiles, los botones se superponen en las esquinas inferiores del lienzo y permiten moverse y saltar a la vez.

## Historia y recuerdos

La introducción muestra la llamada de Michael en el hospital y el regreso de Harry al orfanato. Pulsa **Continuar** en cada fragmento para avanzar.

Ilumina las pinturas ocultas de cada sector. Al descubrir una, se abre su título y el recuerdo de Michael. La partida queda en pausa mientras lees. Puedes volver a consultar las pinturas encontradas desde **Recuerdos**, en el menú principal o en la pausa. La galería se guarda en el navegador junto con el punto de control.

## Niveles

Busca la **Salida** al final de cada sector y selecciona **Entrar** para llegar al siguiente. **Continuar** y **Reintentar** recuperan el nivel y el último punto de control guardados.

1. **El lugar que prometía un nuevo comienzo** presenta la linterna y a La Sombra.
2. **Los pasillos de las voces** añade saltos entre tramos del aula y enemigos que se pueden esquivar.
3. **Lo que quedó en las cenizas** incluye brasas y plataformas que ceden después de pisarlas.
4. **Los recuerdos que no deberían existir** exige cruzar un pasaje elevado y esquivar manos que emergen del suelo. La luz frena al Testigo y revela plataformas ocultas.
5. **Rencor** cierra el recorrido en la cámara final. Sus golpes marcan el suelo antes del impacto. Salta o sal de la zona marcada y aprovecha el momento en que aparece el punto dorado para iluminarlo. Puedes recargar la linterna apagándola sobre la franja de la cámara.

Tras debilitar a Rencor, acércate a la abertura y elige **Entrar en Rencor**. Usa la luz para avanzar hasta Michael y sigue el diálogo para terminar la historia. La partida conserva las pinturas descubiertas y registra que llegaste al final.

## Estructura

| Ruta | Contenido |
| --- | --- |
| `index.html` y `src/main.js` | Página de entrada e inicialización de Phaser |
| `src/config/` | Configuración del motor, el lienzo y las escenas |
| `src/scenes/` | Menú, introducción, niveles, recuerdos y desenlace |
| `src/entities/` | Harry, enemigos y Rencor |
| `src/systems/` | Linterna, combate, salud, audio y guardado |
| `src/data/` | Geometría de los niveles y catálogo de pinturas |
| `src/ui/` | HUD, botones, ilustraciones y controles táctiles |
| `src/assets/` | Fachada del orfanato y audio de la cámara final |

## Créditos

- **Desarrollo y diseño** · Integrantes del grupo indicados en este documento.
- **Fachada del orfanato** · Ilustración SVG creada para el prototipo.
- **Audio de la cámara final** · Ambiente y efectos sintetizados para el juego.
- **Herramientas** · [Phaser](https://phaser.io/) y [Vite](https://vite.dev/).
